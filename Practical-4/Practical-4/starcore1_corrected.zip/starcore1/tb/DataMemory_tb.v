// DataMemory_tb.v - Testbench for Data Memory
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module DataMemory_tb;

    reg                    clk, mem_read, mem_write;
    reg  [`WORD_WIDTH-1:0] address, write_data;
    wire [`WORD_WIDTH-1:0] read_data;

    integer fail_count;

    DataMemory uut (
        .clk       (clk),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .address   (address),
        .write_data(write_data),
        .read_data (read_data)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        $dumpfile("waves/datamem_tb.vcd");
        $dumpvars(0, DataMemory_tb);
    end

    initial begin
        $display("\n=== DataMemory Testbench ===");
        fail_count = 0;
        mem_read = 0; mem_write = 0;
        address  = 0; write_data = 0;

        // T1: Read data[0] from init file — expected 10
        address = 16'd0; mem_read = 1; mem_write = 0; #10;
        if (read_data !== 16'd10) begin
            $display("FAIL [T1]: data[0] expected 10 got %0d", read_data);
            fail_count = fail_count + 1;
        end else $display("PASS [T1]: data[0] = 10 (from init file)");

        // T2: Read data[1] — expected 3  (byte address 2 → word[1])
        address = 16'd2; mem_read = 1; #10;
        if (read_data !== 16'd3) begin
            $display("FAIL [T2]: data[1] expected 3 got %0d", read_data);
            fail_count = fail_count + 1;
        end else $display("PASS [T2]: data[1] = 3 (from init file)");

        // T3: mem_read deasserted → output should be 0
        mem_read = 0; #10;
        if (read_data !== 16'd0) begin
            $display("FAIL [T3]: output not gated, got %0d", read_data);
            fail_count = fail_count + 1;
        end else $display("PASS [T3]: output 0 when mem_read=0");

        // T4: Synchronous write to word[2] (byte addr 4)
        address = 16'd4; write_data = 16'd99; mem_write = 1; mem_read = 0;
        @(posedge clk); #1;
        mem_write = 0;
        // T5: Read it back
        mem_read = 1; #10;
        if (read_data !== 16'd99) begin
            $display("FAIL [T4/T5]: wrote 99, read back %0d", read_data);
            fail_count = fail_count + 1;
        end else $display("PASS [T4/T5]: write then read word[2] = 99");

        // T6: Write does not happen when mem_write=0
        address = 16'd6; write_data = 16'd777; mem_write = 0;
        @(posedge clk); #1;
        mem_read = 1; #10;
        if (read_data !== 16'd0) begin  // word[3] was 0 from init
            $display("FAIL [T6]: unintended write, got %0d", read_data);
            fail_count = fail_count + 1;
        end else $display("PASS [T6]: data unchanged when mem_write=0");

        $display("");
        if (fail_count == 0)
            $display("=== ALL DATA MEMORY TESTS PASSED ===");
        else
            $display("=== %0d DATA MEMORY TESTS FAILED ===", fail_count);

        $finish;
    end

endmodule
