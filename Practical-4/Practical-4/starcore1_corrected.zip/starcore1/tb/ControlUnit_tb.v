// ControlUnit_tb.v - Testbench for ControlUnit
// EEE4120F Practical 4
// Verifies every opcode in the truth table from Section 3.3
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ControlUnit_tb;

    reg  [`OPCODE_WIDTH-1:0] opcode;
    wire reg_dst, alu_src, mem_to_reg, reg_write;
    wire mem_read, mem_write, branch, beq, jump;
    wire [1:0] alu_op;

    integer fail_count;

    ControlUnit uut (
        .opcode    (opcode),
        .reg_dst   (reg_dst),
        .alu_src   (alu_src),
        .mem_to_reg(mem_to_reg),
        .reg_write (reg_write),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .branch    (branch),
        .beq       (beq),
        .alu_op    (alu_op),
        .jump      (jump)
    );

    // Pack all signals for easy comparison
    // {reg_dst, alu_src, mem_to_reg, reg_write, mem_read, mem_write, branch, alu_op[1], alu_op[0], jump}
    // = 10 bits
    wire [9:0] ctrl = {reg_dst, alu_src, mem_to_reg, reg_write,
                       mem_read, mem_write, branch, alu_op, jump};

    task check;
        input [`OPCODE_WIDTH-1:0] op;
        input [9:0] expected;
        input [255:0] name;
        begin
            opcode = op; #5;
            if (ctrl !== expected) begin
                $display("FAIL [%s]: got=%b expected=%b", name, ctrl, expected);
                fail_count = fail_count + 1;
            end else
                $display("PASS [%s]: ctrl=%b", name, ctrl);
        end
    endtask

    initial begin
        $display("\n=== ControlUnit Testbench ===");
        fail_count = 0;

        // Format: {reg_dst, alu_src, mem_to_reg, reg_write, mem_read, mem_write, branch, alu_op[1:0], jump}
        //  LD : 0  1  1  1  1  0  0  10  0  => 0b01_1110_0100 = 10'b0111100100
        check(`OP_LD,  10'b0111100100, "LD ");
        //  ST : 0  1  0  0  0  1  0  10  0  => 10'b0100010100
        check(`OP_ST,  10'b0100010100, "ST ");
        //  ADD R-type: 1  0  0  1  0  0  0  00  0 => 10'b1001000000
        check(`OP_ADD, 10'b1001000000, "ADD");
        check(`OP_SUB, 10'b1001000000, "SUB");
        check(`OP_INV, 10'b1001000000, "INV");
        check(`OP_SHL, 10'b1001000000, "SHL");
        check(`OP_SHR, 10'b1001000000, "SHR");
        check(`OP_AND, 10'b1001000000, "AND");
        check(`OP_OR,  10'b1001000000, "OR ");
        check(`OP_SLT, 10'b1001000000, "SLT");
        //  BEQ: 0  0  0  0  0  0  1  01  0 => 10'b0000001010
        check(`OP_BEQ, 10'b0000001010, "BEQ");
        //  BNE: same ctrl bits as BEQ (branch=1, alu_op=01) except beq=0
        check(`OP_BNE, 10'b0000001010, "BNE");
        //  JMP: 0  0  0  0  0  0  0  00  1 => 10'b0000000001
        check(`OP_JMP, 10'b0000000001, "JMP");
        //  COP (reserved): all zeros
        check(`OP_COP, 10'b0000000000, "COP");
        //  BEQ: beq signal should be 1
        opcode = `OP_BEQ; #5;
        if (beq !== 1'b1) begin
            $display("FAIL [BEQ beq]: beq signal not set");
            fail_count = fail_count + 1;
        end else $display("PASS [BEQ beq]: beq=1 for BEQ");
        //  BNE: beq signal should be 0
        opcode = `OP_BNE; #5;
        if (beq !== 1'b0) begin
            $display("FAIL [BNE beq]: beq signal incorrectly set");
            fail_count = fail_count + 1;
        end else $display("PASS [BNE beq]: beq=0 for BNE");

        $display("");
        if (fail_count == 0)
            $display("=== ALL CONTROL UNIT TESTS PASSED ===");
        else
            $display("=== %0d CONTROL UNIT TESTS FAILED ===", fail_count);

        $finish;
    end

endmodule
