// GPR_tb.v - Testbench for General Purpose Register File
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module GPR_tb;

    reg                        clk, reg_write_en;
    reg  [`REG_ADDR_WIDTH-1:0] read_addr1, read_addr2, write_addr;
    reg  [`WORD_WIDTH-1:0]     write_data;
    wire [`WORD_WIDTH-1:0]     read_data1, read_data2;

    integer fail_count;

    GPR uut (
        .clk          (clk),
        .reg_write_en (reg_write_en),
        .read_addr1   (read_addr1),
        .read_addr2   (read_addr2),
        .write_addr   (write_addr),
        .write_data   (write_data),
        .read_data1   (read_data1),
        .read_data2   (read_data2)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        $dumpfile("waves/gpr_tb.vcd");
        $dumpvars(0, GPR_tb);
    end

    initial begin
        $display("\n=== GPR Testbench ===");
        fail_count    = 0;
        reg_write_en  = 0;
        write_addr    = 0;
        write_data    = 0;
        read_addr1    = 0;
        read_addr2    = 0;

        // T1: R0 hardwired to zero — read without writing
        read_addr1 = 3'd0; #2;
        if (read_data1 !== 16'd0) begin
            $display("FAIL [T1]: R0 not zero, got %0d", read_data1);
            fail_count = fail_count + 1;
        end else $display("PASS [T1]: R0 reads as 0");

        // T2: Write then read R1
        @(posedge clk); #1;
        reg_write_en = 1; write_addr = 3'd1; write_data = 16'd42;
        @(posedge clk); #1;
        reg_write_en = 0;
        read_addr1 = 3'd1; #2;
        if (read_data1 !== 16'd42) begin
            $display("FAIL [T2]: R1 expected 42 got %0d", read_data1);
            fail_count = fail_count + 1;
        end else $display("PASS [T2]: R1 = 42 after write");

        // T3: Write R2 and R3, verify independence
        @(posedge clk); #1;
        reg_write_en = 1; write_addr = 3'd2; write_data = 16'd100;
        @(posedge clk); #1;
        write_addr = 3'd3; write_data = 16'd200;
        @(posedge clk); #1;
        reg_write_en = 0;
        read_addr1 = 3'd2; read_addr2 = 3'd3; #2;
        if (read_data1 !== 16'd100 || read_data2 !== 16'd200) begin
            $display("FAIL [T3]: R2=%0d R3=%0d (exp 100, 200)", read_data1, read_data2);
            fail_count = fail_count + 1;
        end else $display("PASS [T3]: R2=100, R3=200 independent");

        // T4: Write disabled — register should not change
        @(posedge clk); #1;
        reg_write_en = 0; write_addr = 3'd2; write_data = 16'd999;
        @(posedge clk); #1;
        read_addr1 = 3'd2; #2;
        if (read_data1 !== 16'd100) begin
            $display("FAIL [T4]: R2 changed without write-enable, got %0d", read_data1);
            fail_count = fail_count + 1;
        end else $display("PASS [T4]: R2 unchanged when write disabled");

        // T5: Write to R0 — should remain zero
        @(posedge clk); #1;
        reg_write_en = 1; write_addr = 3'd0; write_data = 16'd555;
        @(posedge clk); #1;
        reg_write_en = 0;
        read_addr1 = 3'd0; #2;
        if (read_data1 !== 16'd0) begin
            $display("FAIL [T5]: R0 was overwritten, got %0d", read_data1);
            fail_count = fail_count + 1;
        end else $display("PASS [T5]: R0 remains 0 after write attempt");

        $display("");
        if (fail_count == 0)
            $display("=== ALL GPR TESTS PASSED ===");
        else
            $display("=== %0d GPR TESTS FAILED ===", fail_count);

        $finish;
    end

endmodule
