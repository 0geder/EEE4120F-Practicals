// ALU_Control_tb.v - Testbench for ALU Control Unit
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ALU_Control_tb;

    reg  [1:0]               alu_op;
    reg  [`OPCODE_WIDTH-1:0] opcode;
    wire [`ALU_CTRL_WIDTH-1:0] alu_cnt;

    integer fail_count;

    ALU_Control uut (
        .alu_op (alu_op),
        .opcode (opcode),
        .alu_cnt(alu_cnt)
    );

    task check;
        input [`ALU_CTRL_WIDTH-1:0] expected;
        input [255:0] name;
        begin
            #5;
            if (alu_cnt !== expected) begin
                $display("FAIL [%s]: alu_cnt=%b expected=%b", name, alu_cnt, expected);
                fail_count = fail_count + 1;
            end else
                $display("PASS [%s]: alu_cnt=%b", name, alu_cnt);
        end
    endtask

    initial begin
        $display("\n=== ALU_Control Testbench ===");
        fail_count = 0;

        // ALUOP_RTYPE — each R-type opcode maps to correct ALU function
        alu_op = `ALUOP_RTYPE;
        opcode = `OP_ADD; check(`ALU_ADD, "RTYPE ADD");
        opcode = `OP_SUB; check(`ALU_SUB, "RTYPE SUB");
        opcode = `OP_AND; check(`ALU_AND, "RTYPE AND");
        opcode = `OP_OR;  check(`ALU_OR,  "RTYPE OR ");
        opcode = `OP_INV; check(`ALU_INV, "RTYPE INV");
        opcode = `OP_SHL; check(`ALU_SHL, "RTYPE SHL");
        opcode = `OP_SHR; check(`ALU_SHR, "RTYPE SHR");
        opcode = `OP_SLT; check(`ALU_SLT, "RTYPE SLT");

        // ALUOP_BRANCH — always SUB regardless of opcode
        alu_op = `ALUOP_BRANCH;
        opcode = `OP_BEQ; check(`ALU_SUB, "BRANCH BEQ");
        opcode = `OP_BNE; check(`ALU_SUB, "BRANCH BNE");

        // ALUOP_ITYPE — always ADD regardless of opcode
        alu_op = `ALUOP_ITYPE;
        opcode = `OP_LD; check(`ALU_ADD, "ITYPE LD");
        opcode = `OP_ST; check(`ALU_ADD, "ITYPE ST");

        $display("");
        if (fail_count == 0)
            $display("=== ALL ALU_CONTROL TESTS PASSED ===");
        else
            $display("=== %0d ALU_CONTROL TESTS FAILED ===", fail_count);

        $finish;
    end

endmodule
