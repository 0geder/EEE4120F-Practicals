// InstructionMemory_tb.v - Testbench for Instruction Memory
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module InstructionMemory_tb;

    reg  [`WORD_WIDTH-1:0] pc;
    wire [`WORD_WIDTH-1:0] instruction;

    integer fail_count;

    InstructionMemory uut (
        .pc         (pc),
        .instruction(instruction)
    );

    // Expected instructions from test.prog (corrected encodings)
    reg [`WORD_WIDTH-1:0] expected [0:12];

    initial begin
        expected[0]  = 16'b0000000001000000; // LD  R1, 0(R0)
        expected[1]  = 16'b0000000010000010; // LD  R2, 2(R0)
        expected[2]  = 16'b0010001010011000; // ADD R3, R1, R2
        expected[3]  = 16'b0011001010100000; // SUB R4, R1, R2
        expected[4]  = 16'b0111001010101000; // AND R5, R1, R2
        expected[5]  = 16'b1000001010110000; // OR  R6, R1, R2
        expected[6]  = 16'b1001010001111000; // SLT R7, R2, R1
        expected[7]  = 16'b1011001010000010; // BEQ R1, R2, +2
        expected[8]  = 16'b0010001010001000; // ADD R1, R1, R2
        expected[9]  = 16'b1100001010000001; // BNE R1, R2, +1  (FIXED)
        expected[10] = 16'b0011001010001000; // SUB R1, R1, R2 (skipped)
        expected[11] = 16'b0001000011000100; // ST  R3, 4(R0)
        expected[12] = 16'b1101000000000000; // JMP 0
    end

    integer i;
    initial begin
        $display("\n=== InstructionMemory Testbench ===");
        fail_count = 0;

        for (i = 0; i < 13; i = i + 1) begin
            pc = i * 2;  // byte address
            #10;
            if (instruction !== expected[i]) begin
                $display("FAIL [instr %0d]: got=%b expected=%b",
                         i, instruction, expected[i]);
                fail_count = fail_count + 1;
            end else
                $display("PASS [instr %0d]: 0x%04h", i, instruction);
        end

        $display("");
        if (fail_count == 0)
            $display("=== ALL INSTRUCTION MEMORY TESTS PASSED ===");
        else
            $display("=== %0d INSTRUCTION MEMORY TESTS FAILED ===", fail_count);

        $finish;
    end

endmodule
