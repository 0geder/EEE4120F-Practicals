// StarCore1_tb.v - Integration testbench for StarCore-1
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module StarCore1_tb;

    reg  clk, reset;
    wire [`WORD_WIDTH-1:0]   debug_pc;
    wire [`WORD_WIDTH-1:0]   debug_instr;
    wire [`OPCODE_WIDTH-1:0] debug_opcode;

    integer fail_count;
    integer cycle;

    StarCore1 uut (
        .clk         (clk),
        .reset       (reset),
        .debug_pc    (debug_pc),
        .debug_instr (debug_instr),
        .debug_opcode(debug_opcode)
    );

    // 100 MHz clock
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        $dumpfile("waves/star.vcd");
        $dumpvars(0, StarCore1_tb);
    end

    // Execution trace — fires on every rising edge
    initial begin
        $display("\n%-6s %-6s %-18s %-6s %s",
                 "Cycle", "PC", "Instruction", "OP", "Notes");
        $display("%s", {60{"-"}});
    end

    always @(posedge clk) begin
        if (!reset)
            $display("%-6d 0x%04h %b  %04b",
                     cycle, debug_pc, debug_instr, debug_opcode);
    end

    initial begin
        $display("\n=== StarCore-1 Integration Testbench ===\n");
        fail_count = 0;
        cycle      = 0;

        // ── Reset ────────────────────────────────────────────────
        reset = 1; #20;
        reset = 0;
        $display("[%0t] Reset released\n", $time);

        // Run enough cycles to execute the 13-instruction program
        // (13 instructions + a few extra to let stores settle)
        repeat (16) begin
            @(posedge clk);
            cycle = cycle + 1;
        end

        // ── Verify register results ───────────────────────────────
        $display("\n--- Register File Verification ---");
        #1; // let combinational settle

        // R1 should be 13 (loaded 10, added 3 at instr 8)
        if (uut.dp.reg_file.reg_array[1] == 16'd13)
            $display("PASS: R1 = %0d (expected 13)", uut.dp.reg_file.reg_array[1]);
        else begin
            $display("FAIL: R1 = %0d (expected 13)", uut.dp.reg_file.reg_array[1]);
            fail_count = fail_count + 1;
        end

        // R2 should be 3 (loaded from data mem[1])
        if (uut.dp.reg_file.reg_array[2] == 16'd3)
            $display("PASS: R2 = %0d (expected 3)", uut.dp.reg_file.reg_array[2]);
        else begin
            $display("FAIL: R2 = %0d (expected 3)", uut.dp.reg_file.reg_array[2]);
            fail_count = fail_count + 1;
        end

        // R3 = ADD R1+R2 = 13
        if (uut.dp.reg_file.reg_array[3] == 16'd13)
            $display("PASS: R3 = %0d (expected 13)", uut.dp.reg_file.reg_array[3]);
        else begin
            $display("FAIL: R3 = %0d (expected 13)", uut.dp.reg_file.reg_array[3]);
            fail_count = fail_count + 1;
        end

        // R4 = SUB R1-R2 = 7  (original R1=10, R2=3)
        if (uut.dp.reg_file.reg_array[4] == 16'd7)
            $display("PASS: R4 = %0d (expected 7)", uut.dp.reg_file.reg_array[4]);
        else begin
            $display("FAIL: R4 = %0d (expected 7)", uut.dp.reg_file.reg_array[4]);
            fail_count = fail_count + 1;
        end

        // R5 = AND 10&3 = 2
        if (uut.dp.reg_file.reg_array[5] == 16'd2)
            $display("PASS: R5 = %0d (expected 2)", uut.dp.reg_file.reg_array[5]);
        else begin
            $display("FAIL: R5 = %0d (expected 2)", uut.dp.reg_file.reg_array[5]);
            fail_count = fail_count + 1;
        end

        // R6 = OR 10|3 = 11
        if (uut.dp.reg_file.reg_array[6] == 16'd11)
            $display("PASS: R6 = %0d (expected 11)", uut.dp.reg_file.reg_array[6]);
        else begin
            $display("FAIL: R6 = %0d (expected 11)", uut.dp.reg_file.reg_array[6]);
            fail_count = fail_count + 1;
        end

        // R7 = SLT R2<R1 = (3<10) = 1
        if (uut.dp.reg_file.reg_array[7] == 16'd1)
            $display("PASS: R7 = %0d (expected 1)", uut.dp.reg_file.reg_array[7]);
        else begin
            $display("FAIL: R7 = %0d (expected 1)", uut.dp.reg_file.reg_array[7]);
            fail_count = fail_count + 1;
        end

        // Data memory: ST R3, 4(R0) → data_mem[2] = 13
        if (uut.dp.dmem.data_mem[2] == 16'd13)
            $display("PASS: data_mem[2] = %0d (expected 13)", uut.dp.dmem.data_mem[2]);
        else begin
            $display("FAIL: data_mem[2] = %0d (expected 13)", uut.dp.dmem.data_mem[2]);
            fail_count = fail_count + 1;
        end

        // ── Summary ───────────────────────────────────────────────
        $display("\n=========================================");
        if (fail_count == 0)
            $display("  ALL INTEGRATION TESTS PASSED!");
        else
            $display("  %0d INTEGRATION TEST(S) FAILED", fail_count);
        $display("=========================================\n");

        $finish;
    end

endmodule
