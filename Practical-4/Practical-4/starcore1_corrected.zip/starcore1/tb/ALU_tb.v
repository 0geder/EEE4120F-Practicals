// ALU_tb.v - Testbench for ALU module
// EEE4120F Practical 4
`timescale 1ns / 1ps
`include "../src/Parameter.v"

module ALU_tb;

    reg  [`WORD_WIDTH-1:0]     a, b;
    reg  [`ALU_CTRL_WIDTH-1:0] alu_control;
    wire [`WORD_WIDTH-1:0]     result;
    wire                       zero;

    integer fail_count;
    integer test_num;

    ALU uut (
        .a          (a),
        .b          (b),
        .alu_control(alu_control),
        .result     (result),
        .zero       (zero)
    );

    initial begin
        $dumpfile("waves/alu_tb.vcd");
        $dumpvars(0, ALU_tb);
    end

    // ── Check task ───────────────────────────────────────────────
    task check_result;
        input [`WORD_WIDTH-1:0] expected;
        input [63:0]            id;
        begin
            if (result !== expected) begin
                $display("FAIL [T%0d]: got=%0d (0x%h) expected=%0d (0x%h)",
                         id, result, result, expected, expected);
                fail_count = fail_count + 1;
            end else begin
                $display("PASS [T%0d]: result=%0d", id, result);
            end
        end
    endtask

    initial begin
        $display("\n=== ALU Testbench ===");
        fail_count = 0;
        test_num   = 1;

        // T1: ADD 10 + 3 = 13
        a = 16'd10; b = 16'd3; alu_control = `ALU_ADD; #10;
        check_result(16'd13, test_num); test_num = test_num + 1;

        // T2: ADD overflow 0xFFFF + 1 = 0
        a = 16'hFFFF; b = 16'd1; alu_control = `ALU_ADD; #10;
        check_result(16'd0, test_num); test_num = test_num + 1;

        // T3: SUB 10 - 3 = 7
        a = 16'd10; b = 16'd3; alu_control = `ALU_SUB; #10;
        check_result(16'd7, test_num); test_num = test_num + 1;

        // T4: SUB same value → zero flag
        a = 16'd7; b = 16'd7; alu_control = `ALU_SUB; #10;
        if (zero !== 1'b1) begin
            $display("FAIL [T%0d]: zero flag not set", test_num);
            fail_count = fail_count + 1;
        end else $display("PASS [T%0d]: zero flag set for 7-7=0", test_num);
        test_num = test_num + 1;

        // T5: AND 10 & 3 = 2
        a = 16'd10; b = 16'd3; alu_control = `ALU_AND; #10;
        check_result(16'd2, test_num); test_num = test_num + 1;

        // T6: OR 10 | 3 = 11
        a = 16'd10; b = 16'd3; alu_control = `ALU_OR; #10;
        check_result(16'd11, test_num); test_num = test_num + 1;

        // T7: INV ~0x000F = 0xFFF0
        a = 16'h000F; b = 16'd0; alu_control = `ALU_INV; #10;
        check_result(16'hFFF0, test_num); test_num = test_num + 1;

        // T8: SHL 1 << 3 = 8
        a = 16'd1; b = 16'd3; alu_control = `ALU_SHL; #10;
        check_result(16'd8, test_num); test_num = test_num + 1;

        // T9: SHR 16 >> 2 = 4
        a = 16'd16; b = 16'd2; alu_control = `ALU_SHR; #10;
        check_result(16'd4, test_num); test_num = test_num + 1;

        // T10: SLT 3 < 10 → 1
        a = 16'd3; b = 16'd10; alu_control = `ALU_SLT; #10;
        check_result(16'd1, test_num); test_num = test_num + 1;

        // T11: SLT 10 < 3 → 0
        a = 16'd10; b = 16'd3; alu_control = `ALU_SLT; #10;
        check_result(16'd0, test_num); test_num = test_num + 1;

        // T12: zero flag clear for non-zero result
        a = 16'd5; b = 16'd3; alu_control = `ALU_ADD; #10;
        if (zero !== 1'b0) begin
            $display("FAIL [T%0d]: zero flag incorrectly set", test_num);
            fail_count = fail_count + 1;
        end else $display("PASS [T%0d]: zero flag clear for 5+3=8", test_num);
        test_num = test_num + 1;

        $display("");
        if (fail_count == 0)
            $display("=== ALL %0d ALU TESTS PASSED ===", test_num - 1);
        else
            $display("=== %0d/%0d ALU TESTS FAILED ===", fail_count, test_num - 1);

        $finish;
    end

endmodule
