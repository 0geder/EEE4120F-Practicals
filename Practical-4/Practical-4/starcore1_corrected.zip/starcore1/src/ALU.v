// ALU.v - 16-bit Arithmetic Logic Unit
// EEE4120F Practical 4

`include "Parameter.v"

module ALU (
    input  wire [`WORD_WIDTH-1:0]     a,
    input  wire [`WORD_WIDTH-1:0]     b,
    input  wire [`ALU_CTRL_WIDTH-1:0] alu_control,
    output reg  [`WORD_WIDTH-1:0]     result,
    output wire                       zero
);

    // Zero flag: high when result is all zeros
    assign zero = (result == {`WORD_WIDTH{1'b0}});

    always @(*) begin
        case (alu_control)
            `ALU_ADD : result = a + b;
            `ALU_SUB : result = a - b;
            `ALU_AND : result = a & b;
            `ALU_OR  : result = a | b;
            `ALU_INV : result = ~a;
            `ALU_SHL : result = a << b[3:0];
            `ALU_SHR : result = a >> b[3:0];
            `ALU_SLT : result = (a < b) ? 16'd1 : 16'd0;
            default  : result = a + b;
        endcase
    end

endmodule
