// ALU_Control.v - ALU control signal decoder
// EEE4120F Practical 4
// CORRECTED: R-type opcode mapping uses ISA-accurate opcode constants

`include "Parameter.v"

module ALU_Control (
    input  wire [1:0]               alu_op,
    input  wire [`OPCODE_WIDTH-1:0] opcode,
    output reg  [`ALU_CTRL_WIDTH-1:0] alu_cnt
);

    always @(*) begin
        case (alu_op)

            `ALUOP_RTYPE: begin
                // Use opcode to select the ALU operation
                case (opcode)
                    `OP_ADD : alu_cnt = `ALU_ADD;
                    `OP_SUB : alu_cnt = `ALU_SUB;
                    `OP_AND : alu_cnt = `ALU_AND;
                    `OP_OR  : alu_cnt = `ALU_OR;
                    `OP_INV : alu_cnt = `ALU_INV;
                    `OP_SHL : alu_cnt = `ALU_SHL;
                    `OP_SHR : alu_cnt = `ALU_SHR;
                    `OP_SLT : alu_cnt = `ALU_SLT;
                    default : alu_cnt = `ALU_ADD;
                endcase
            end

            `ALUOP_BRANCH: begin
                // Branch uses SUB to check equality
                alu_cnt = `ALU_SUB;
            end

            `ALUOP_ITYPE: begin
                // LD/ST always uses ADD for address calculation
                alu_cnt = `ALU_ADD;
            end

            default: alu_cnt = `ALU_ADD;

        endcase
    end

endmodule
