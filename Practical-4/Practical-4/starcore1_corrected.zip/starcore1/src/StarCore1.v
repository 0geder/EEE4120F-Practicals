// StarCore1.v - Top-level StarCore-1 processor
// EEE4120F Practical 4
// CORRECTED: beq signal wired between ControlUnit and Datapath

`include "Parameter.v"

module StarCore1 (
    input  wire clk,
    input  wire reset,
    // Debug outputs
    output wire [`WORD_WIDTH-1:0]   debug_pc,
    output wire [`WORD_WIDTH-1:0]   debug_instr,
    output wire [`OPCODE_WIDTH-1:0] debug_opcode
);

    // ── Control signals ──────────────────────────────────────────
    wire reg_dst, alu_src, mem_to_reg, reg_write;
    wire mem_read, mem_write, branch, beq, jump;
    wire [1:0] alu_op;
    wire [`OPCODE_WIDTH-1:0] opcode;

    // ── Datapath ─────────────────────────────────────────────────
    Datapath dp (
        .clk       (clk),
        .reset     (reset),
        .reg_dst   (reg_dst),
        .alu_src   (alu_src),
        .mem_to_reg(mem_to_reg),
        .reg_write (reg_write),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .branch    (branch),
        .beq       (beq),
        .alu_op    (alu_op),
        .jump      (jump),
        .opcode    (opcode),
        .debug_pc  (debug_pc),
        .debug_instr(debug_instr)
    );

    // ── Control Unit ─────────────────────────────────────────────
    ControlUnit cu (
        .opcode    (opcode),
        .reg_dst   (reg_dst),
        .alu_src   (alu_src),
        .mem_to_reg(mem_to_reg),
        .reg_write (reg_write),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .branch    (branch),
        .beq       (beq),
        .alu_op    (alu_op),
        .jump      (jump)
    );

    assign debug_opcode = opcode;

endmodule
