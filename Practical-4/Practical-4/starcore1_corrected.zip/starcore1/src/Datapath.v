// Datapath.v - Integrated datapath for StarCore-1
// EEE4120F Practical 4
// CORRECTED:
//   1. Jump target uses pc_current[15:13] not offset bits
//   2. BEQ/BNE branch sense uses 'beq' signal from ControlUnit
//   3. Instruction field names match the manual (ws_rtype vs ws_itype)
//   4. DataMemory write port feeds RS2 (read_data2) as per spec

`include "Parameter.v"

module Datapath (
    input  wire        clk,
    input  wire        reset,
    // Control signals in
    input  wire        reg_dst,
    input  wire        alu_src,
    input  wire        mem_to_reg,
    input  wire        reg_write,
    input  wire        mem_read,
    input  wire        mem_write,
    input  wire        branch,
    input  wire        beq,       // 1 = BEQ sense, 0 = BNE sense
    input  wire [1:0]  alu_op,
    input  wire        jump,
    // Opcode out to ControlUnit
    output wire [`OPCODE_WIDTH-1:0] opcode,
    // Debug outputs
    output wire [`WORD_WIDTH-1:0]   debug_pc,
    output wire [`WORD_WIDTH-1:0]   debug_instr
);

    // ── Internal signals ─────────────────────────────────────────
    wire [`WORD_WIDTH-1:0] pc_current, pc_next, pc_plus2;
    wire [`WORD_WIDTH-1:0] instruction;
    wire [`WORD_WIDTH-1:0] read_data1, read_data2;
    wire [`WORD_WIDTH-1:0] write_back_data;
    wire [`WORD_WIDTH-1:0] alu_in_b;
    wire [`WORD_WIDTH-1:0] alu_result;
    wire [`WORD_WIDTH-1:0] sign_ext_imm;
    wire [`WORD_WIDTH-1:0] branch_offset;
    wire [`WORD_WIDTH-1:0] branch_target;
    wire [`WORD_WIDTH-1:0] mem_read_data;
    wire [`REG_ADDR_WIDTH-1:0] write_reg_addr;
    wire [`ALU_CTRL_WIDTH-1:0] alu_cnt;
    wire zero_flag;
    wire branch_taken;

    // ── Instruction field extraction ─────────────────────────────
    // R-type: [15:12]OP [11:9]RS1 [8:6]RS2  [5:3]WS   [2:0]unused
    // I-type: [15:12]OP [11:9]RS1 [8:6]WS   [5:0]Offset
    // J-type: [15:12]OP [11:0]Offset
    assign opcode       = instruction[15:12];
    wire [2:0] rs1      = instruction[11:9];
    wire [2:0] rs2      = instruction[8:6];   // also I-type WS
    wire [2:0] ws_rtype = instruction[5:3];   // R-type destination
    wire [5:0] imm6     = instruction[5:0];
    wire [11:0] j_offset = instruction[11:0];

    // ── PC register ──────────────────────────────────────────────
    reg [`WORD_WIDTH-1:0] pc_reg;

    always @(posedge clk or posedge reset) begin
        if (reset) pc_reg <= 16'd0;
        else       pc_reg <= pc_next;
    end

    assign pc_current = pc_reg;
    assign pc_plus2   = pc_current + 16'd2;

    // ── Instruction memory ───────────────────────────────────────
    InstructionMemory imem (
        .pc         (pc_current),
        .instruction(instruction)
    );

    // ── Register file ────────────────────────────────────────────
    // RegDst mux: 1 → R-type WS field [5:3], 0 → I-type WS field [8:6]
    assign write_reg_addr = reg_dst ? ws_rtype : rs2;

    GPR reg_file (
        .clk          (clk),
        .reg_write_en (reg_write),
        .read_addr1   (rs1),
        .read_addr2   (rs2),
        .write_addr   (write_reg_addr),
        .write_data   (write_back_data),
        .read_data1   (read_data1),
        .read_data2   (read_data2)
    );

    // Write-back mux: 1 → memory data, 0 → ALU result
    assign write_back_data = mem_to_reg ? mem_read_data : alu_result;

    // ── Sign extension: 6-bit → 16-bit ──────────────────────────
    assign sign_ext_imm = {{10{imm6[5]}}, imm6};

    // ── ALU B operand mux ────────────────────────────────────────
    assign alu_in_b = alu_src ? sign_ext_imm : read_data2;

    // ── ALU control ──────────────────────────────────────────────
    ALU_Control alu_ctrl (
        .alu_op (alu_op),
        .opcode (opcode),
        .alu_cnt(alu_cnt)
    );

    // ── ALU ──────────────────────────────────────────────────────
    ALU alu_unit (
        .a          (read_data1),
        .b          (alu_in_b),
        .alu_control(alu_cnt),
        .result     (alu_result),
        .zero       (zero_flag)
    );

    // ── Data memory ──────────────────────────────────────────────
    DataMemory dmem (
        .clk       (clk),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .address   (alu_result),
        .write_data(read_data2),   // store RS2
        .read_data (mem_read_data)
    );

    // ── Branch logic ─────────────────────────────────────────────
    // BEQ branches when zero=1, BNE branches when zero=0
    // 'beq' signal from ControlUnit selects the sense
    assign branch_taken = branch & (beq ? zero_flag : ~zero_flag);

    // Branch target: PC+2 + SignExt(imm6) << 1  (byte offset)
    assign branch_offset = {sign_ext_imm[14:0], 1'b0};
    assign branch_target = pc_plus2 + branch_offset;

    // ── Jump target ──────────────────────────────────────────────
    // PC := {PC[15:13], offset[11:0], 1'b0}
    // FIXED: upper 3 bits come from current PC, NOT from the offset
    wire [`WORD_WIDTH-1:0] jump_target;
    assign jump_target = {pc_current[15:13], j_offset, 1'b0};

    // ── Next-PC mux ──────────────────────────────────────────────
    wire [`WORD_WIDTH-1:0] pc_after_branch;
    assign pc_after_branch = branch_taken ? branch_target : pc_plus2;
    assign pc_next         = jump ? jump_target : pc_after_branch;

    // ── Debug outputs ─────────────────────────────────────────────
    assign debug_pc    = pc_current;
    assign debug_instr = instruction;

endmodule
