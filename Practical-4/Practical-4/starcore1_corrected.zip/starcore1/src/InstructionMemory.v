// InstructionMemory.v - 16-word Instruction ROM
// EEE4120F Practical 4

`include "Parameter.v"

module InstructionMemory (
    input  wire [`WORD_WIDTH-1:0] pc,
    output wire [`WORD_WIDTH-1:0] instruction
);

    reg [`WORD_WIDTH-1:0] instr_mem [`INSTR_MEM_DEPTH-1:0];

    // PC is byte-addressed; use bits [4:1] to index 16 word-aligned entries
    wire [3:0] addr = pc[4:1];

    initial begin
        $readmemb("test/test.prog", instr_mem);
    end

    assign instruction = instr_mem[addr];

endmodule
