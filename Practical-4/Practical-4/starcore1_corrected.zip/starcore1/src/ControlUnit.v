// ControlUnit.v - Main control signal decoder
// EEE4120F Practical 4
// CORRECTED:
//   1. All opcode constants now match the StarCore ISA spec (Section 3.2)
//   2. Control signal truth table matches Section 3.3 exactly
//   3. Added separate 'beq' output so Datapath can distinguish BEQ from BNE

`include "Parameter.v"

module ControlUnit (
    input  wire [`OPCODE_WIDTH-1:0] opcode,
    output reg  reg_dst,
    output reg  alu_src,
    output reg  mem_to_reg,
    output reg  reg_write,
    output reg  mem_read,
    output reg  mem_write,
    output reg  branch,     // asserted for both BEQ and BNE
    output reg  beq,        // asserted only for BEQ (so datapath knows sense)
    output reg  [1:0] alu_op,
    output reg  jump
);

    always @(*) begin
        // Safe defaults — all signals deasserted
        reg_dst    = 1'b0;
        alu_src    = 1'b0;
        mem_to_reg = 1'b0;
        reg_write  = 1'b0;
        mem_read   = 1'b0;
        mem_write  = 1'b0;
        branch     = 1'b0;
        beq        = 1'b0;
        alu_op     = 2'b00;
        jump       = 1'b0;

        case (opcode)

            // ── LD: load word ─────────────────────────────────────
            `OP_LD: begin
                reg_dst    = 1'b0;   // write to instr[8:6] (I-type WS)
                alu_src    = 1'b1;   // ALU B = sign-extended immediate
                mem_to_reg = 1'b1;   // write-back from memory
                reg_write  = 1'b1;
                mem_read   = 1'b1;
                alu_op     = `ALUOP_ITYPE;
            end

            // ── ST: store word ────────────────────────────────────
            `OP_ST: begin
                alu_src    = 1'b1;
                mem_write  = 1'b1;
                alu_op     = `ALUOP_ITYPE;
            end

            // ── R-type: ADD, SUB, INV, SHL, SHR, AND, OR, SLT ───
            `OP_ADD, `OP_SUB, `OP_INV,
            `OP_SHL, `OP_SHR, `OP_AND,
            `OP_OR,  `OP_SLT: begin
                reg_dst   = 1'b1;   // write to instr[5:3] (R-type WS)
                reg_write = 1'b1;
                alu_op    = `ALUOP_RTYPE;
            end

            // ── BEQ ───────────────────────────────────────────────
            `OP_BEQ: begin
                branch = 1'b1;
                beq    = 1'b1;      // BEQ: branch when zero=1
                alu_op = `ALUOP_BRANCH;
            end

            // ── BNE ───────────────────────────────────────────────
            `OP_BNE: begin
                branch = 1'b1;
                beq    = 1'b0;      // BNE: branch when zero=0
                alu_op = `ALUOP_BRANCH;
            end

            // ── JMP ───────────────────────────────────────────────
            `OP_JMP: begin
                jump = 1'b1;
            end

            // ── COP (reserved) — all outputs remain 0 (NOP) ──────
            `OP_COP: begin
                // intentional no-op
            end

            // ── Undefined opcodes — treat as NOP ─────────────────
            default: begin
                // all signals stay 0
            end

        endcase
    end

endmodule
