// GPR.v - 8 x 16-bit General Purpose Register File
// EEE4120F Practical 4

`include "Parameter.v"

module GPR (
    input  wire                        clk,
    input  wire                        reg_write_en,
    input  wire [`REG_ADDR_WIDTH-1:0]  read_addr1,
    input  wire [`REG_ADDR_WIDTH-1:0]  read_addr2,
    input  wire [`REG_ADDR_WIDTH-1:0]  write_addr,
    input  wire [`WORD_WIDTH-1:0]      write_data,
    output wire [`WORD_WIDTH-1:0]      read_data1,
    output wire [`WORD_WIDTH-1:0]      read_data2
);

    reg [`WORD_WIDTH-1:0] reg_array [`REG_COUNT-1:0];

    integer i;
    initial begin
        for (i = 0; i < `REG_COUNT; i = i + 1)
            reg_array[i] = 16'd0;
    end

    // Asynchronous read — R0 is hardwired to zero
    assign read_data1 = (read_addr1 == 3'd0) ? 16'd0 : reg_array[read_addr1];
    assign read_data2 = (read_addr2 == 3'd0) ? 16'd0 : reg_array[read_addr2];

    // Synchronous write
    always @(posedge clk) begin
        if (reg_write_en && write_addr != 3'd0)
            reg_array[write_addr] <= write_data;
    end

endmodule
