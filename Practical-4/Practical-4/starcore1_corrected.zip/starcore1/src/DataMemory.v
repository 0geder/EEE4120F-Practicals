// DataMemory.v - 8-word Data RAM
// EEE4120F Practical 4
// FIXED: address indexing uses [3:1] for byte-addressed, word-aligned access

`include "Parameter.v"

module DataMemory (
    input  wire                   clk,
    input  wire                   mem_read,
    input  wire                   mem_write,
    input  wire [`WORD_WIDTH-1:0] address,
    input  wire [`WORD_WIDTH-1:0] write_data,
    output wire [`WORD_WIDTH-1:0] read_data
);

    reg [`WORD_WIDTH-1:0] data_mem [`DATA_MEM_DEPTH-1:0];

    // Word-aligned index: discard the byte-select LSB, take 3 bits
    wire [2:0] addr_idx = address[3:1];

    initial begin
        $readmemb("test/test.data", data_mem);
    end

    // Synchronous write
    always @(posedge clk) begin
        if (mem_write)
            data_mem[addr_idx] <= write_data;
    end

    // Asynchronous read gated by mem_read
    assign read_data = mem_read ? data_mem[addr_idx] : 16'd0;

endmodule
