// Parameter.v - Shared definitions for StarCore-1 processor
// EEE4120F Practical 4
// CORRECTED: opcodes match the StarCore ISA specification table

`ifndef PARAMETER_V
`define PARAMETER_V

// ── Word / bus widths ────────────────────────────────────────────
`define WORD_WIDTH      16
`define REG_ADDR_WIDTH   3
`define OPCODE_WIDTH     4
`define ALU_CTRL_WIDTH   3

// ── Memory dimensions ────────────────────────────────────────────
`define INSTR_MEM_DEPTH 16
`define DATA_MEM_DEPTH   8
`define REG_COUNT        8

// ── Simulation parameters ────────────────────────────────────────
`define SIM_TIME   200
`define CLK_PERIOD  10

// ── ISA Opcodes (must match Section 3.2 of the manual exactly) ───
//   OP   Mnemonic
`define OP_LD   4'b0000   // Load word
`define OP_ST   4'b0001   // Store word
`define OP_ADD  4'b0010   // Add
`define OP_SUB  4'b0011   // Subtract
`define OP_INV  4'b0100   // Bitwise NOT
`define OP_SHL  4'b0101   // Logical left shift
`define OP_SHR  4'b0110   // Logical right shift
`define OP_AND  4'b0111   // Bitwise AND
`define OP_OR   4'b1000   // Bitwise OR
`define OP_SLT  4'b1001   // Set on less-than
`define OP_COP  4'b1010   // Reserved co-processor (NOP)
`define OP_BEQ  4'b1011   // Branch if equal
`define OP_BNE  4'b1100   // Branch if not equal
`define OP_JMP  4'b1101   // Unconditional jump

// ── ALU function-select codes (3-bit ALUcnt) ─────────────────────
`define ALU_ADD  3'b000
`define ALU_SUB  3'b001
`define ALU_AND  3'b010
`define ALU_OR   3'b011
`define ALU_INV  3'b100
`define ALU_SHL  3'b101
`define ALU_SHR  3'b110
`define ALU_SLT  3'b111

// ── ALUOp mode codes (2-bit, from ControlUnit to ALU_Control) ────
`define ALUOP_RTYPE   2'b00   // R-type: use opcode to pick operation
`define ALUOP_BRANCH  2'b01   // Branch: always SUB for comparison
`define ALUOP_ITYPE   2'b10   // I-type: always ADD for address calc

`endif
